<?php
// ============================================================
// index.php — Tela principal de login (Google / Apple / Email)
// Se já estiver logado, redireciona para o perfil
// ============================================================
session_start();

if (isset($_SESSION["usuario_id"])) {
    header("Location: perfil.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Entrar</title>
  <link rel="stylesheet" href="styles/login.css" />
</head>
<body>
<div class="login-page">
  <div class="login-card">

    <!-- Logo -->
    <div class="lumi-logo">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" fill="#4d298a" opacity="0.2"/>
        <circle cx="12" cy="12" r="5" fill="#4d298a"/>
        <circle cx="12" cy="12" r="2" fill="#fff"/>
      </svg>
      <span class="lumi-logo-name">Lumi</span>
    </div>

    <!-- Título -->
    <div class="login-header" style="margin-bottom:1.5rem;">
      <h1>Bem-vindo(a)</h1>
    </div>
    <p style="color:var(--text-muted);font-size:0.88rem;margin-bottom:1.5rem;margin-top:-1rem;">
      Escolha como deseja entrar
    </p>

    <!-- Botões sociais -->
    <div class="social-buttons">

      <!-- Google -->
      <a href="#" class="btn-social" onclick="alert('Login com Google em breve!'); return false;">
        <svg width="18" height="18" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
        Entrar com Google
      </a>

      <!-- Apple -->
      <a href="#" class="btn-social" onclick="alert('Login com Apple em breve!'); return false;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.7 9.05 7.4c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.53 4zm-3.1-17.26c.06 2.17-1.94 3.98-3.9 3.77-.27-1.93 1.76-3.98 3.9-3.77z"/>
        </svg>
        Entrar com Apple
      </a>

      <!-- Email -->
      <a href="loginEmail.php" class="btn-social btn-email">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect x="2" y="4" width="20" height="16" rx="2"/>
          <polyline points="2,4 12,13 22,4"/>
        </svg>
        Entrar com E-mail
      </a>

    </div>

    <div class="divider">ou</div>

    <div class="login-footer">
      Ainda não tem uma conta?
      <a href="register.php">Registrar</a>
    </div>

  </div>
</div>
</body>
</html>
