<?php
// ============================================================
// questionario.php — Seleção de nível e matérias
// Salva na sessão e redireciona para o cadastro
// ============================================================
session_start();

if (isset($_SESSION["usuario_id"])) {
    header("Location: perfil.php");
    exit;
}

// Matérias disponíveis por nível
$materias = [
    "fundamental1" => [
        ["nome" => "Português",  "img" => "port.png"],
        ["nome" => "Matemática", "img" => "mat.png"],
        ["nome" => "Ciências",   "img" => "cien.png"],
        ["nome" => "História",   "img" => "hist.png"],
        ["nome" => "Geografia",  "img" => "geo.png"],
    ],
    "fundamental2" => [
        ["nome" => "Português",  "img" => "port.png"],
        ["nome" => "Matemática", "img" => "mat.png"],
        ["nome" => "Ciências",   "img" => "cien.png"],
        ["nome" => "Física",     "img" => "fisic.png"],
        ["nome" => "Química",    "img" => "quim.png"],
        ["nome" => "Biologia",   "img" => "bio.png"],
        ["nome" => "História",   "img" => "hist.png"],
        ["nome" => "Geografia",  "img" => "geo.png"],
        ["nome" => "Inglês",     "img" => "ing.png"],
        ["nome" => "Redação",    "img" => "red.png"],
    ],
    "medio" => [
        ["nome" => "Português",  "img" => "port.png"],
        ["nome" => "Matemática", "img" => "mat.png"],
        ["nome" => "Física",     "img" => "fisic.png"],
        ["nome" => "Química",    "img" => "quim.png"],
        ["nome" => "Biologia",   "img" => "bio.png"],
        ["nome" => "História",   "img" => "hist.png"],
        ["nome" => "Geografia",  "img" => "geo.png"],
        ["nome" => "Inglês",     "img" => "ing.png"],
        ["nome" => "Filosofia",  "img" => "filos.png"],
        ["nome" => "Sociologia", "img" => "socio.png"],
        ["nome" => "Redação",    "img" => "red.png"],
    ],
    "vestibular" => [
        ["nome" => "Português",  "img" => "port.png"],
        ["nome" => "Matemática", "img" => "mat.png"],
        ["nome" => "Geometria",  "img" => "geome.png"],
        ["nome" => "Física",     "img" => "fisic.png"],
        ["nome" => "Química",    "img" => "quim.png"],
        ["nome" => "Biologia",   "img" => "bio.png"],
        ["nome" => "História",   "img" => "hist.png"],
        ["nome" => "Geografia",  "img" => "geo.png"],
        ["nome" => "Inglês",     "img" => "ing.png"],
        ["nome" => "Filosofia",  "img" => "filos.png"],
        ["nome" => "Sociologia", "img" => "socio.png"],
        ["nome" => "Literatura", "img" => "liter.png"],
        ["nome" => "Redação",    "img" => "red.png"],
    ],
];

$niveis = [
    ["id" => "fundamental1", "titulo" => "Fundamental I",  "sub" => "1º ao 5º ano",  "img" => "fundICard.png",  "tooltip" => "Português, Matemática, Ciências, História e Geografia."],
    ["id" => "fundamental2", "titulo" => "Fundamental II", "sub" => "6º ao 9º ano",  "img" => "fundIICard.png", "tooltip" => "Inclui Física, Química, Biologia, Inglês e Redação."],
    ["id" => "medio",        "titulo" => "Ensino Médio",   "sub" => "1º ao 3º série", "img" => "medioCard.png",  "tooltip" => "Todas as matérias do Fund. II + Filosofia e Sociologia."],
    ["id" => "vestibular",   "titulo" => "Vestibular",     "sub" => "Preparatório",   "img" => "vestCard.png",   "tooltip" => "Revisão completa + Literatura e Geometria para o ENEM."],
];

// Processa o POST do step 2 (matérias selecionadas)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["nivel"], $_POST["materias"])) {
    $_SESSION["quiz_nivel"]   = $_POST["nivel"];
    $_SESSION["quiz_materias"] = $_POST["materias"]; // array
    header("Location: register.php");
    exit;
}

// Step atual — 1 (nível) ou 2 (matérias)
$step  = isset($_GET["nivel"]) ? 2 : 1;
$nivel = $_GET["nivel"] ?? "";

// Valida o nível passado na URL
if ($step === 2 && !array_key_exists($nivel, $materias)) {
    header("Location: questionario.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Escolha seu perfil</title>
  <link rel="stylesheet" href="styles/questionario.css" />
</head>
<body>
<div class="quiz-page">

  <!-- Steps -->
  <div class="quiz-steps">
    <div class="quiz-step-dot <?= $step === 1 ? 'active' : 'done' ?>"></div>
    <div class="quiz-step-dot <?= $step === 2 ? 'active' : '' ?>"></div>
  </div>

  <?php if ($step === 1): ?>
  <!-- ════════ STEP 1 — Nível ════════ -->

    <a href="login.php" class="quiz-back">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
      Voltar
    </a>

    <div class="quiz-header">
      <h1>Qual seu nível?</h1>
      <p>Escolha o nível escolar que melhor te representa</p>
    </div>

    <div class="nivel-grid">
      <?php foreach ($niveis as $n): ?>
        <a href="questionario.php?nivel=<?= $n['id'] ?>" class="quiz-card">

          <div class="quiz-card-img-area">
            <img
              src="assets/<?= $n['img'] ?>"
              alt="<?= $n['titulo'] ?>"
              class="quiz-card-img"
              style="width:72px;height:72px;"
            />
          </div>

          <div class="quiz-card-divider"></div>

          <div class="quiz-card-body">
            <div>
              <p class="quiz-card-title"><?= $n['titulo'] ?></p>
              <p class="quiz-card-sub"><?= $n['sub'] ?></p>
            </div>
            <button class="quiz-card-btn" >Selecionar</button>
          </div>

        </a>
      <?php endforeach; ?>
    </div>

  <?php else: ?>
  <!-- ════════ STEP 2 — Matérias ════════ -->

    <a href="questionario.php" class="quiz-back">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
      Voltar
    </a>

    <div class="quiz-header">
      <h1>Quais matérias quer estudar?</h1>
      <p>Você pode trocar quando quiser depois</p>
      <!-- Counter atualizado via JS -->
      <div class="quiz-counter">
        <span id="countSel">0</span>/<?= count($materias[$nivel]) ?>
      </div>
    </div>

    <form method="POST" action="" id="formMaterias">
      <input type="hidden" name="nivel" value="<?= htmlspecialchars($nivel) ?>" />

      <div class="materia-scroll-wrapper">
        <div class="materia-row">
          <?php foreach ($materias[$nivel] as $m): ?>
            <label class="quiz-card" id="card-<?= htmlspecialchars($m['nome']) ?>">
              <input
                type="checkbox"
                name="materias[]"
                value="<?= htmlspecialchars($m['nome']) ?>"
                style="display:none"
                onchange="toggleCard(this)"
              />
              <div class="quiz-card-img-area">
                <img
                  src="assets/materias/<?= $m['img'] ?>"
                  alt="<?= $m['nome'] ?>"
                  class="quiz-card-img"
                  style="width:56px;height:56px;"
                />
              </div>
              <div class="quiz-card-divider"></div>
              <div class="quiz-card-body">
                <p class="quiz-card-title"><?= htmlspecialchars($m['nome']) ?></p>
                <div>
                  <button class="quiz-card-btn" id="btn-<?= htmlspecialchars($m['nome']) ?>">Selecionar</button>
                </div>
              </div>
            </label>
          <?php endforeach; ?>
        </div>
      </div>

      <button type="submit" class="quiz-continue" id="btnContinuar">
        Continuar
      </button>
    </form>


  <?php endif; ?>

</div>

<?php if ($step === 2): ?>
<script>
let selecionadas = 0;

function toggleCard(input) {
  const nome = input.value;
  const card = document.getElementById("card-" + nome);
  const btn  = document.getElementById("btn-" + nome);

  if (input.checked) {
    card.classList.add("selected");
    btn.textContent = "Selecionado";
    selecionadas++;
  } else {
    card.classList.remove("selected");
    btn.textContent = "Selecionar";
    selecionadas--;
  }

  // Atualiza counter
  document.getElementById("countSel").textContent = selecionadas;

  // Ativa/desativa botão continuar
  const btnCont = document.getElementById("btnContinuar");
  btnCont.classList.toggle("ativo", selecionadas > 0);
}

// Clique no card inteiro seleciona o checkbox
document.querySelectorAll(".quiz-card").forEach(card => {
  card.addEventListener("click", function(e) {
    if (e.target.tagName === "INPUT") return;
    const checkbox = this.querySelector("input[type=checkbox]");
    if (checkbox) {
      checkbox.checked = !checkbox.checked;
      toggleCard(checkbox);
    }
  });
});
</script>
<?php endif; ?>

</body>
</html>
