<?php
// ============================================================
// register.php — Cadastro — lê nível e matérias da sessão
// ============================================================
session_start();
require_once "db.php";

if (isset($_SESSION["usuario_id"])) {
    header("Location: perfil.php");
    exit;
}

$erros  = [];
$nivel   = $_SESSION["quiz_nivel"]    ?? null;
$materias = $_SESSION["quiz_materias"] ?? [];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome      = trim($_POST["nome"]      ?? "");
    $username  = trim($_POST["username"]  ?? "");
    $email     = trim($_POST["email"]     ?? "");
    $senha     = $_POST["senha"]          ?? "";
    $confirmar = $_POST["confirmar"]      ?? "";

    if (empty($nome))     $erros["nome"]     = "Nome é obrigatório.";
    if (empty($username)) $erros["username"] = "Username é obrigatório.";
    elseif (str_contains($username, " ")) $erros["username"] = "Username não pode ter espaços.";
    if (empty($email))        $erros["email"] = "E-mail é obrigatório.";
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) $erros["email"] = "E-mail inválido.";
    if (empty($senha))        $erros["senha"] = "Senha é obrigatória.";
    elseif (strlen($senha) < 6) $erros["senha"] = "Mínimo de 6 caracteres.";
    if (empty($confirmar))    $erros["confirmar"] = "Confirme sua senha.";
    elseif ($senha !== $confirmar) $erros["confirmar"] = "As senhas não coincidem.";

    if (empty($erros)) {
        $stmt = $pdo->prepare("SELECT id FROM pessoas WHERE email = ? OR nome = ?");
        $stmt->execute([$email, $nome]);
        if ($stmt->fetch()) $erros["geral"] = "E-mail ou username já cadastrado.";
    }

    if (empty($erros)) {
        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO pessoas (nome, email, senha) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $email, $hash]);
        $id = $pdo->lastInsertId();

        // Salva matérias na tabela materiaUsuario (se existir e tiver preferências)
        if ($nivel && !empty($materias)) {
            $stmtM = $pdo->prepare("INSERT INTO materiaUsuario (usuario_id, nivel, materia) VALUES (?, ?, ?)");
            foreach ($materias as $mat) {
                $stmtM->execute([$id, $nivel, $mat]);
            }
        }

        // Loga e limpa preferências da sessão
        $_SESSION["usuario_id"]    = $id;
        $_SESSION["usuario_nome"]  = $nome;
        $_SESSION["usuario_email"] = $email;
        unset($_SESSION["quiz_nivel"], $_SESSION["quiz_materias"]);

        header("Location: perfil.php");
        exit;
    }
}

// Label amigável do nível
$nivelLabels = [
    "fundamental1" => "Fundamental I",
    "fundamental2" => "Fundamental II",
    "medio"        => "Ensino Médio",
    "vestibular"   => "Vestibular",
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Criar conta</title>
  <link rel="stylesheet" href="styles/register.css" />
</head>
<body>
<div class="register-page">
  <div class="register-card">

    <div class="register-header">
      <a href="<?= $nivel ? 'questionario.php?nivel=' . $nivel : 'questionario.php' ?>" class="btn-back" title="Voltar">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="15 18 9 12 15 6"/>
        </svg>
      </a>
      <div class="register-header-text">
        <h1>Criar conta</h1>
        <p>Preencha os dados para se cadastrar</p>
      </div>
    </div>

    <!-- Badge de preferências -->
    <?php if ($nivel && !empty($materias)): ?>
      <div class="pref-badge">
        <strong><?= $nivelLabels[$nivel] ?? $nivel ?></strong>
        &middot;
        <?= htmlspecialchars(implode(", ", $materias)) ?>
      </div>
    <?php endif; ?>

    <!-- Erro geral -->
    <?php if (!empty($erros["geral"])): ?>
      <div class="alert alert-error" style="margin-bottom:1rem;">
        <?= htmlspecialchars($erros["geral"]) ?>
      </div>
    <?php endif; ?>

    <form class="register-form" method="POST" action="register.php">

      <div class="form-row">
        <div class="input-wrapper">
          <label class="input-label" for="nome">Nome</label>
          <input class="input-field <?= isset($erros['nome']) ? 'input-error' : '' ?>"
            type="text" id="nome" name="nome" placeholder="Seu nome"
            value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>" />
          <?php if (isset($erros["nome"])): ?><span class="error-msg"><?= $erros["nome"] ?></span><?php endif; ?>
        </div>
        <div class="input-wrapper">
          <label class="input-label" for="username">Username</label>
          <input class="input-field <?= isset($erros['username']) ? 'input-error' : '' ?>"
            type="text" id="username" name="username" placeholder="@usuario"
            value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" />
          <?php if (isset($erros["username"])): ?><span class="error-msg"><?= $erros["username"] ?></span><?php endif; ?>
        </div>
      </div>

      <div class="input-wrapper">
        <label class="input-label" for="email">E-mail</label>
        <input class="input-field <?= isset($erros['email']) ? 'input-error' : '' ?>"
          type="email" id="email" name="email" placeholder="seu@email.com"
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" />
        <?php if (isset($erros["email"])): ?><span class="error-msg"><?= $erros["email"] ?></span><?php endif; ?>
      </div>

      <div class="input-wrapper">
        <label class="input-label" for="senha">Senha</label>
        <input class="input-field <?= isset($erros['senha']) ? 'input-error' : '' ?>"
          type="password" id="senha" name="senha" placeholder="Mínimo 6 caracteres"
          oninput="calcularForca(this.value)" />
        <?php if (isset($erros["senha"])): ?><span class="error-msg"><?= $erros["senha"] ?></span><?php endif; ?>
        <div class="strength-bar-wrapper" id="strengthBars" style="display:none">
          <div class="strength-bar" id="bar1"></div>
          <div class="strength-bar" id="bar2"></div>
          <div class="strength-bar" id="bar3"></div>
        </div>
        <p class="strength-label" id="strengthLabel"></p>
      </div>

      <div class="input-wrapper">
        <label class="input-label" for="confirmar">Confirmar Senha</label>
        <input class="input-field <?= isset($erros['confirmar']) ? 'input-error' : '' ?>"
          type="password" id="confirmar" name="confirmar" placeholder="Repita a senha" />
        <?php if (isset($erros["confirmar"])): ?><span class="error-msg"><?= $erros["confirmar"] ?></span><?php endif; ?>
      </div>

      <button type="submit" class="btn-primary">Criar conta</button>
    </form>

    <div class="register-footer">
      Já tem uma conta? <a href="loginEmail.php">Entrar</a>
    </div>

  </div>
</div>

<script>
function calcularForca(senha) {
  const bars  = document.getElementById("strengthBars");
  const label = document.getElementById("strengthLabel");
  const b = [document.getElementById("bar1"), document.getElementById("bar2"), document.getElementById("bar3")];

  if (!senha) { bars.style.display = "none"; label.textContent = ""; return; }
  bars.style.display = "flex";

  let p = 0;
  if (senha.length >= 8) p++;
  if (/[A-Z]/.test(senha) && /[0-9]/.test(senha)) p++;
  if (/[^A-Za-z0-9]/.test(senha)) p++;
  if (p === 0) p = 1;

  const cls = ["", "weak", "medium", "strong"];
  const lbl = ["", "Fraca", "Média", "Forte"];
  b.forEach(bar => bar.className = "strength-bar");
  for (let i = 0; i < p; i++) b[i].classList.add(cls[p]);
  label.textContent = "Força da senha: " + lbl[p];
}
</script>
</body>
</html>
