<?php
// ============================================================
// home.php — Landing page Lumi
// ============================================================
session_start();

// Se já estiver logado, vai direto pro perfil
if (isset($_SESSION["usuario_id"])) {
    header("Location: perfil.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Aprenda do seu jeito</title>
  <link rel="stylesheet" href="styles/home.css" />
</head>
<body>

<!-- ── HEADER ── -->
<header class="home-header">
  <a href="home.php" class="home-logo">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="10" fill="#4d298a" opacity="0.2"/>
      <circle cx="12" cy="12" r="5" fill="#4d298a"/>
      <circle cx="12" cy="12" r="2" fill="#fff"/>
    </svg>
    <span class="home-logo-name">Lumi</span>
  </a>
  <nav class="home-nav">
    <a href="#funcionalidades" class="nav-link">Funcionalidades</a>
    <a href="#sobre" class="nav-link">Sobre</a>
    <a href="login.php" class="nav-link-btn">Entrar</a>
  </nav>
</header>

<!-- ── HERO ── -->
<section class="home-hero">
  <div class="hero-tag">Plataforma educacional brasileira</div>
  <h1 class="hero-title">
    Aprenda no seu ritmo,<br>do <em>jeito certo</em>
  </h1>
  <p class="hero-subtitle">
    Do Fundamental ao Vestibular — questões inteligentes, progresso real e estudo que funciona.
  </p>
  <div class="hero-actions">
    <a href="login.php" class="btn-primary">Começar agora</a>
    <a href="#funcionalidades" class="btn-secondary">Saiba mais</a>
  </div>
</section>

<!-- ── FUNCIONALIDADES ── -->
<section class="home-section" id="funcionalidades">
  <p class="section-label fade-up">Funcionalidades</p>
  <h2 class="section-title fade-up">Tudo que você precisa para estudar de verdade</h2>

  <div class="features-grid">

    <div class="feature-card fade-up">
      <div class="feature-card-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z"/>
        </svg>
      </div>
      <h3>Questões por matéria</h3>
      <p>Conteúdo alinhado à grade curricular do Fundamental I ao Vestibular, com questões objetivas e dissertativas.</p>
    </div>

    <div class="feature-card fade-up">
      <div class="feature-card-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
        </svg>
      </div>
      <h3>Progresso em tempo real</h3>
      <p>Acompanhe sua evolução com indicadores de desempenho, sequências de estudo e histórico de atividades.</p>
    </div>

    <div class="feature-card fade-up">
      <div class="feature-card-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/>
          <circle cx="9" cy="7" r="4"/>
          <path d="M23 21v-2a4 4 0 00-3-3.87"/>
          <path d="M16 3.13a4 4 0 010 7.75"/>
        </svg>
      </div>
      <h3>Ranking entre alunos</h3>
      <p>Compare seu desempenho com outros estudantes da mesma matéria e mantenha a motivação alta.</p>
    </div>

  </div>
</section>

<!-- ── HIGHLIGHT ── -->
<section class="highlight-section" id="sobre">
  <div class="highlight-inner">
    <div class="highlight-text fade-up">
      <p class="section-label">Por que o Lumi</p>
      <h2 class="section-title">Construído para o estudante brasileiro</h2>
      <p>
        O Lumi foi desenvolvido com foco na grade curricular nacional, do 1º ano do Fundamental
        até o Vestibular. Sem conteúdo genérico — só o que você realmente vai precisar.
      </p>
      <a href="login.php" class="btn-primary">Criar minha conta</a>
    </div>
    <div class="highlight-visual fade-up">
      <p style="color:var(--text-muted);font-size:0.82rem;">Imagem do produto</p>
    </div>
  </div>
</section>

<!-- ── FOOTER ── -->
<footer style="border-top: 1px solid var(--border);">
  <div class="home-footer">
    <span class="footer-brand">Lumi</span>
    <span class="footer-copy">© 2026 Lumi. Todos os direitos reservados.</span>
  </div>
</footer>

<script>
// Animação fade-up no scroll
const observer = new IntersectionObserver(
  entries => entries.forEach(e => { if (e.isIntersecting) e.target.classList.add("visible"); }),
  { threshold: 0.15 }
);
document.querySelectorAll(".fade-up").forEach(el => observer.observe(el));
</script>

</body>
</html>
