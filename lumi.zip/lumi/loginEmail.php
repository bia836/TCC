<?php
// ============================================================
// loginEmail.php — Login com e-mail e senha
// ============================================================
session_start();
require_once "db.php";

if (isset($_SESSION["usuario_id"])) {
    header("Location: perfil.php");
    exit;
}

$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";

    if (empty($email) || empty($senha)) {
        $erro = "Preencha todos os campos.";
    } else {
        // Busca o usuário pelo e-mail
        $stmt = $pdo->prepare("SELECT id, nome, email, senha FROM pessoas WHERE id = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if (!$usuario || !password_verify($senha, $usuario["senha"])) {
            $erro = "E-mail ou senha incorretos.";
        } else {
            // Login ok — salva na sessão
            $_SESSION["usuario_id"]   = $usuario["id"];
            $_SESSION["usuario_nome"] = $usuario["nome"];
            $_SESSION["usuario_email"] = $usuario["email"];

            header("Location: perfil.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Entrar com e-mail</title>
  <link rel="stylesheet" href="styles/login.css" />
</head>
<body>
<div class="login-page">
  <div class="login-card">

    <!-- Logo -->
    <div class="lumi-logo">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="10" fill="#4d298a" opacity="0.2"/>
        <circle cx="12" cy="12" r="5" fill="#4d298a"/>
        <circle cx="12" cy="12" r="2" fill="#fff"/>
      </svg>
      <span class="lumi-logo-name">Lumi</span>
    </div>

    <!-- Cabeçalho com botão voltar -->
    <div class="login-header">
      <a href="index.php" class="btn-back" title="Voltar">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="15 18 9 12 15 6"/>
        </svg>
      </a>
      <h1>Entrar com e-mail</h1>
    </div>

    <!-- Erro -->
    <?php if ($erro): ?>
      <div class="alert alert-error" style="margin-bottom:1rem;"><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <!-- Formulário -->
    <form class="login-form" method="POST" action="loginEmail.php">

      <div class="input-wrapper">
        <label class="input-label" for="email">E-mail</label>
        <input
          class="input-field <?= $erro ? 'input-error' : '' ?>"
          type="email"
          id="email"
          name="email"
          placeholder="seu@email.com"
          value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
          autocomplete="email"
        />
      </div>

      <div class="input-wrapper">
        <label class="input-label" for="senha">Senha</label>
        <input
          class="input-field <?= $erro ? 'input-error' : '' ?>"
          type="password"
          id="senha"
          name="senha"
          placeholder="Sua senha"
          autocomplete="current-password"
        />
      </div>

      <button type="submit" class="btn-primary">Entrar</button>

    </form>

    <div class="divider">ou</div>

    <div class="login-footer">
      Ainda não tem uma conta?
      <a href="register.php">Registrar</a>
    </div>

  </div>
</div>
</body>
</html>
