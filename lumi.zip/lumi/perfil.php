<?php
// ============================================================
// perfil.php — Tela de perfil do usuário logado
// Redireciona para login se não estiver autenticado
// ============================================================
session_start();

if (!isset($_SESSION["usuario_id"])) {
    header("Location: index.php");
    exit;
}

$nome  = $_SESSION["usuario_nome"];
$email = $_SESSION["usuario_email"];

// Inicial do nome para o avatar
$inicial = strtoupper(mb_substr($nome, 0, 1));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Lumi — Perfil</title>
  <link rel="stylesheet" href="styles/perfil.css" />
</head>
<body>
<div class="perfil-page">
  <div class="perfil-card">

    <!-- Avatar com inicial -->
    <div class="perfil-avatar"><?= $inicial ?></div>

    <!-- Saudação -->
    <p class="perfil-tag">Bem-vindo(a) de volta</p>
    <h1 class="perfil-nome"><?= htmlspecialchars($nome) ?></h1>

    <!-- Informações -->
    <div class="perfil-info-bloco">
      <div class="perfil-info-item">
        <p class="perfil-info-label">E-mail de contato</p>
        <p class="perfil-info-valor"><?= htmlspecialchars($email) ?></p>
      </div>
    </div>

    <!-- Botão sair -->
    <a href="logout.php" class="btn-sair">Sair da conta</a>

  </div>
</div>
</body>
</html>
