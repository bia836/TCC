<?php
// ============================================================
// db.php — Conexão com MySQL via PDO
// Inclua este arquivo em qualquer página que precise do banco
// ============================================================

$host     = "localhost";
$porta    = "3306";        // porta do XAMPP
$banco    = "bancotcc";
$usuario  = "root";
$senha    = "";            // sem senha no XAMPP padrão

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$porta;dbname=$banco;charset=utf8",
        $usuario,
        $senha,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die(json_encode(["erro" => "Erro ao conectar: " . $e->getMessage()]));
}
