<?php
// ============================================================
// logout.php — Encerra a sessão e volta para o login
// ============================================================
session_start();
session_destroy();
header("Location: index.php");
exit;
